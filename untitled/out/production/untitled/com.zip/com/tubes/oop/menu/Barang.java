package com.tubes.oop.menu;


import com.tubes.oop.Models.Customer;

import java.util.Scanner;

public class Barang {
    Customer customer;
    private String id_barang, id_penjual, berat, stock;
    private final int pembelian_minimum = 1;
    private double harga_satuan;
    private String nama_barang, kondisi_barang, deskripsi_barang;

    Scanner sc = new Scanner(System.in);



    public String getId_barang() {
        return id_barang;
    }

    public String getId_penjual() {
        return id_penjual;
    }

    public String getBerat() {
        return berat;
    }

    public String getStock() {
        return stock;
    }

    public String getPembelian_minimum() {
        return pembelian_minimum;
    }

    public double getHarga_satuan() {
        return harga_satuan;
    }

    public String getNama_barang() {
        return nama_barang;
    }

    public String getKondisi_barang() {
        return kondisi_barang;
    }

    public String getDeskripsi_barang() {
        return deskripsi_barang;
    }

    public void setId_barang(String id_barang) {
        this.id_barang = id_barang;
    }

    public void setId_penjual(String id_penjual) {
        this.id_penjual = id_penjual;
    }

    public void setBerat(String berat) {
        this.berat = berat;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public void setHarga_satuan(double harga_satuan) {
        this.harga_satuan = harga_satuan;
    }

    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    public void setKondisi_barang(String kondisi_barang) {
        this.kondisi_barang = kondisi_barang;
    }

    public void setDeskripsi_barang(String deskripsi_barang) {
        this.deskripsi_barang = deskripsi_barang;
    }

    public void TampilanBarang(){
        System.out.println("ID Barang: " + getId_barang());
        System.out.println("Name: " + getNama_barang());
        System.out.println("harga: " + getHarga_satuan());
        System.out.println("quantitas: " + getStock());

        System.out.println("");

    }
    public void TambahBarang(){

    }


}
