package com.tubes.oop.cmd;

import com.tubes.oop.Controller.UserController;
import com.tubes.oop.Models.Customer;
import com.tubes.oop.menu.Barang;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Customer c = new Customer();
        Barang b = new Barang();
        UserController u = new UserController();
        Scanner sc = new Scanner(System.in);
        u.Register(c);
        u.Log_in(c);

        public void Menu(Customer c){
            c.pilihanMenu();

            // inputan menu
            System.out.println("masukan pilihan: ");
            String pilihan = sc.nextLine();

            // pilihan menu
            if (pilihan == "1") {
                u.pilihBarang(b);
            }
            else if (pilihan == "2") {

            }
        }

    }

}
